# ETL Python Project 📋

This project implements an ETL (Extract, Transform, Load) process using Python. The system extracts data from REST APIs, performs transformations, and loads the data into a target database.

## 🚀 Features

- Data extraction via REST API using requests library
- Data transformation using pandas
- Loading into relational database
- Execution logs
- Error handling

## 📦 Prerequisites

- Python >= 3.8
- pip install -r requirements.txt

## 🛠️ Main Dependencies

- requests==2.31.0
- pandas==2.1.0
- python-dotenv==1.0.0
- sqlalchemy==2.0.0

## 🔧 Setup

1. Clone the repository
```bash
git clone https://github.com/your-username/etl-python.git
cd etl-python
```

2. Set up virtual environment
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
```

3. Install dependencies
```bash
pip install -r requirements.txt
```

4. Configure environment variables by creating a .env file:
```
API_KEY=your_api_key
DB_CONNECTION=postgresql://user:password@localhost:5432/database
```

## 📖 How to Use

```bash
python src/main.py
```

## 🗂️ Project Structure

```
etl-python/
├── src/
│   ├── extract/
│   ├── transform/
│   ├── load/
│   └── main.py
├── tests/
├── .env.example
├── requirements.txt
└── README.md
```

## 🤝 Contributing

1. Fork the project
2. Create your feature branch (`git checkout -b feature/new-feature`)
3. Commit your changes (`git commit -m 'Add new feature'`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Open a Pull Request

## 📝 License

This project is under the MIT license. See the LICENSE file for more details.