from dashboard.ibovespa_dashboard import IbovespaDashboard
from utils.logger import get_logger

logger = get_logger(__name__)

def main():
    try:
        dashboard = IbovespaDashboard()
        dashboard.run(debug=True)
        logger.info("Dashboard started successfully")
    except Exception as e:
        logger.error(f"Failed to start dashboard: {str(e)}")
        raise

if __name__ == "__main__":
    main()